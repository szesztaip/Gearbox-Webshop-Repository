﻿namespace EmailTest.Dto
{
    public record EmailDto(string To,string Subject,string Body);
}
