﻿using EmailTest.Dto;
namespace EmailTest.Service.IEmailServices
{
    public interface IEmailService
    {
        void SendEmail(EmailDto email);
    }
}
